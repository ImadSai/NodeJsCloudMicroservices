#!/usr/bin/env bash
# shellcheck disable=SC1003

# Patch for yaml.sh

# Suppression des variables shell créées par le parseur pour
# un fichier et un prefix fourni.
# Necessaire lorsque le parseur est executé sur deux fichiers consecutifs differents dans la même session shell.
# A appeler entre les 2 exécutions.
unset_variables_for_file_and_prefix() {
    local yaml_file="$1"
    local prefix="$2"
    local yaml_string
    yaml_string="$(parse_yaml "$yaml_file" "$prefix")"
    unset_variables "${yaml_string}"
}

# Lorsque l'on appelle qu'une seule fois le parseur yaml pour un fichier et pour un prefix, on a aucun risque
# d'avoir des collisions de noms, donc on peut se passer du UNSET qui est très long.
create_variables_without_unset() {
    local yaml_file="$1"
    local prefix="$2"
    yaml_string="$(parse_yaml "$yaml_file" "$prefix")"
    # suppression du unset ici.
    eval "${yaml_string}"
}
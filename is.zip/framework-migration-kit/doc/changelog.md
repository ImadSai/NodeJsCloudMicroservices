# Nouveautés de la version

## 26/08/2021
* :sparkles: Ajout d'un mode "diag" adapté au "Rapport de Qualimétrie" du pipeline GitLab.
* :rocket: Réactivation de l'analyse de tous les application.yml du projet
* :bug: Multiples corrections mineures dans les vérifications.

## 18/08/2021
* :bug: Correction du module de détection de JUnit4
* :fire: Suppression du module de détection de la version du framework qui faisait doublon avec la vérification faite par le CICD.
* :recycle: Amélioration de la précision du module de détection des properties inutiles dans le POM.XML

## 12/08/2021
* Optimisation du support du format YAML pour le rendre beaucoup plus rapide à l'exécution.
* Ajout de règles supplémentaires
  * Ajout du check sur le nomProgramme, qui doit être inferieur ou égal 8 caractères
  * Ajout du check sur la présence de config XML Spring maintenant interdite
  * Ajout des checks pour les librairies commons-lang et commons-collections maintenant interdites dans tout nouveau projet
  * Ajout des checks pour les librairies axis et hibernate maintenant interdites dans tout nouveau projet
  * Ajout du check pour le scope test de la dépendance assu-starter-test qui est parfois oublié
  * Le warning concernant l'analyse d'un seul 'application.yml' n'apparait maintenant plus qu'en mode YAML
  * Suppression du check qui souhaitait la présence d'un FilterRegistrationBean<XXX>, car celui-ci n'est plus obligatoire
  * Ajout du check sur l'ancienne propriété health.vault.enabled qui a changé de nom.

## 05/07/2021
* Ajout du support du format YAML pour la configuration des applications
  * FMK détecte à chaque démarrage le mode de properties utilisé (YAML ou PROPERTIES)
  * Toutes les vérifications de propriétés de configuration peuvent maintenant être effectuées aussi bien sur des
  fichiers "application.properties" que "application.yaml" (ou "application.yml"), en revanche, à l'heure actuelle en mode YAML, seuls les dossiers "src/config/dev_local" sont vérifiés pour des contraintes de performances. C'est à vous de vous assurer de la cohérence avec les autres environnements.
* Les propriétés valorisées à "${symbol_dollar}" ne sont plus remontées par FMK à cause d'une limite du parseur YAML utilisé.

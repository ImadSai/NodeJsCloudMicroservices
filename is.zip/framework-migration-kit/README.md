# Framework Migration Kit (FMK)

## Présentation

FMK est l'outil d'aide à la migration des applications basées sur le Framework Java ASSU. Il permet d'aider le développeur à réaliser des montées de version du Framework ASSU.

Actuellement, il est utilisable pour réaliser une migration depuis 3.70.X vers COBALT 2021.1.4.

## Changelog

Pour les changements de la version actuelle, c'est ici : 
* [Nouveautés de la version](doc/changelog.md)

## Fonctionnalités

FMK n'a pas vocation à être une usine à gaz, il ne sait pas tout faire.

Afin de pouvoir le mettre à jour chaque fois qu'une nouvelle version du Framework est publiée, il doit rester simple à modifier.

Actuellement, il permet de **Produire une check-list**, la plus exhaustive possible, des éléments qui doivent être modifiés pour réaliser la migration.

Concrêtement :
* le mode **CHECKONLY** produit une check-list en analysant les POM.XML, les classes JAVA et les fichiers properties à la recherche d'éléments nécessitant une action, comme :
  * des dépendances obsolètes à supprimer (et à remplacer par une alternative s'il y a lieu),
  * des dépendances "officielles" à remplacer par leur équivalent ASSU,
  * des dépendances sorties du framework à ajouter dans le projet lui-même,
  * des plugins maven obsolètes à remplacer,
  * des classes de configurations à modifier,
  * des classes deprecated à remplacer,
  * des morceaux de codes à refactorer,
  * des annotations à remplacer ou supprimer,
  * des propriétés obsolètes à supprimer ou remplacer,
  * des propriétés recommandées qui sont manquantes,

Ce mode inclut également une vérification de certaines bonnes pratiques JAVA. La correction de ces remontées n'est pas obligatoire pour que la migration soit fonctionnelle, mais elle est fortement conseillée.
  
## Installation de FMK

### Prérequis

* Maven 3.X
* Java 8 ou +
* Git et GitBash

### Installation 

* Cloner le projet FMK
```shell
# A l'endroit souhaité, récupération du projet Framework-Migration-Kit (FMK)
git clone https://sources.assu.socgen/sms/tools/framework-migration-kit.git
```

* Ajouter dans le **PATH** (de git-bash) : 
  * le chemin vers le dossier bin du JDK (déjà OK sur un poste de dev)
  * le chemin vers le dossier bin de Maven (déjà OK sur un poste de dev)
  * le chemin vers le dossier bin de FMK

Pour l'ajout dans le PATH sous git-bash, on peut procéder ainsi : 
```shell
# Edition du fichier .bashrc qui est chargé lors de l'ouverture d'un terminal
vim ~/.bashrc

# Ajout de chemins à la variable d'environnement PATH
# Remplacer /c/Apps/JDK/ par son dossier d'install de JAVA
# Remplacer /c/Apps/maven/maven-3.3.9/bin par son dossier d'install de Maven
# Remplacer /d/x199795/dev/framework-migration-kit/ par le dossier dans lequel FMK a été cloné
export PATH=$PATH:/c/Apps/JDK/bin:/c/Apps/maven/maven-3.3.9/bin:/d/X199795/dev/framework-migration-kit/bin
```

## Utilisation 

:warning: L'outil est à utiliser sous git-bash uniquement.

### Prérequis

* L'outil utilise Java et Maven, ils doivent donc être accessible en ligne de commande. (Cf. Installation)
* Le projet doit être correct au niveau "Maven" du terme. En effet, **si l'arborescence des dépendances ne peut pas être calculée, l'outil ne pourra pas démarrer**.

### Lancement

Il est fortement recommandé d'utiliser FMK sur un dépot GIT "propre", et de préférence sur une nouvelle branche.

#### En mode CHECKONLY (aucune modification)

En mode CHECKONLY, **aucun changement** ne sera effectué sur votre projet.

```shell
# Se placer à la racine du projet JAVA
cd /d/dev/mon-projet
fmk checkonly

# Affichage du rapport de migration
fmk report
```
![FMK checkonly](doc/img/fmk-checkonly.png "FMK checkonly")

## Rapport de migration

Le rapport est généré dans le dossier **.fmkreport**, à la racine de votre projet.

Ce rapport est découpé en plusieurs fichiers : 
* Un pour l'étape de vérification des bonnes pratiques Java sans rapport avec la migration,
* Un pour l'étape de vérification des POM.XML,
* Un pour l'étape de vérification du code Java et des properties,

Ces rapports reprennent exactement la même structure que la synthèse qui sort en couleur dans la console, mais ils comportent, pour chaque item analysé, des détails sur :
* ce qui a été trouvé concernant l'item,
* ce qui doit être fait pour réaliser la migration (en mode CHECKONLY).

Exemple d'un rapport de migration en mode **CHECKONLY** :

![FMK report (checkonly)](doc/img/fmk-report-exemple-checkonly.png "FMK report (checkonly)")

### Afficher et naviguer dans le rapport de migration

L'ouverture de ce rapport peut se faire avec la commande :
```shell
fmk report
```

L'affichage se fait avec le "pager" unix **LESS**. Il est donc possible de naviguer dans le rapport de la manière suivante : 
```shell
':n'         pour passer au rapport suivant.
':p'         pour revenir au rapport precedent.
'ESPACE'     pour defiler d'une page
'q'          pour quitter
```

### Fichiers produits par FMK

Actuellement, FMK laisse ses fichiers temporaires dans le projet, il faudra donc veiller à les supprimer avant tout commit (ou à les ajouter au .gitignore).

Attention donc à ne pas commit : 
* *.lst (pour le listing des dependances, au niveau de chaque POM.XML),
* *.log (pour le résultat de la commande mvn dependency:list),
* .fmk-report/* (pour les rapports générés)

Il est prévu un mode permettant de nettoyer ces fichiers à l'avenir.